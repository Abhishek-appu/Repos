namespace Simulator.Api.Configuration;

public sealed class SimulationOptions
{
    public const string SectionName = "Simulation";
    private static readonly int[] DefaultSpeeds = [1, 2, 5, 10];

    /// <summary>
    /// When true, the product/data stores are replaced by in-process fakes that only log.
    /// Useful for running locally without the real store services.
    /// </summary>
    public bool UseSimulatedStores { get; set; }

    /// <summary>Speed multipliers the user may choose. Defaults to 1, 2, 5 and 10.</summary>
    public int[] AllowedSpeeds { get; set; } = [];

    public IReadOnlyList<int> EffectiveSpeeds =>
        AllowedSpeeds.Length > 0 ? AllowedSpeeds.Distinct().Order().ToArray() : DefaultSpeeds;

    /// <summary>
    /// Depth logs have no natural clock, so at 1x one row is sent every this many ms.
    /// At 2x half that, and so on.
    /// </summary>
    public int DepthRowIntervalMs { get; set; } = 1000;

    /// <summary>Upper limit for a single wait between time rows (protects against big gaps in the data).</summary>
    public int MaxRowDelayMs { get; set; } = 60_000;

    public int MaxLoopCount { get; set; } = 100;

    /// <summary>How long the stop endpoint waits for a running job to finish cancelling.</summary>
    public int StopWaitTimeoutSeconds { get; set; } = 10;
}
