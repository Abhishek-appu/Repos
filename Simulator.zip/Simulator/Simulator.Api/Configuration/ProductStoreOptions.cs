namespace Simulator.Api.Configuration;

public sealed class ProductStoreOptions
{
    public const string SectionName = "ProductStore";
    public string BaseUrl { get; set; } = "";
    public string ApiKey { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 30;
}
