# Simulator API (.NET 10)

Upload a CSV, LAS or WITSML log file, pick a speed, and the simulator sends the header to the
**Product Store** and the data rows to the **Data Store** at that speed.

## Run

```
cd Simulator.Api
dotnet run
```

Swagger opens at `https://localhost:7180/swagger`. In Development, `Simulation:UseSimulatedStores` is `true`, so
store calls are only logged. Set it to `false` and fill in `ProductStore` / `DataStore` in `appsettings.json` to
call the real services. `Simulator.Api.http` has ready-made requests. `samples/valid` and `samples/invalid` have test files.

## Flow

| Step | Endpoint | What happens |
|---|---|---|
| 1. Upload | `POST /api/jobs` (multipart: `File` only) | File is validated (3 checks below). If valid it is stored in `App_Data/jobs/{jobId}.{ext}` and a job is created in status `Received`. |
| 2. Choose speed and start | `POST /api/jobs/{id}/start` `{ "speed": 1 \| 2 \| 5 \| 10, "loopCount": 1 }` | File is parsed, the header is inserted into the Product Store, then rows are sent to the Data Store at the chosen speed. |
| 3. Stop | `POST /api/jobs/{id}/stop` | Cancels a running job. |

Other endpoints: `POST /api/jobs/validate` (checks only, nothing stored), `GET /api/jobs/options` (allowed speeds,
limits, file types), `GET /api/jobs`, `GET /api/jobs/{id}` (status, progress, status history), `GET /health`.

## Upload validation

Each upload returns a report with three checks. Each check is `Passed`, `Failed` or `Skipped`, with messages.
Later checks are skipped when an earlier one fails. Upload returns **201** with the job and the report, or **400** with the report.

| Check | CSV | LAS | WITSML |
|---|---|---|---|
| **Format** | `.csv` | `.las` | `.xml` / `.witsml` |
| | The extension must be supported **and** the content must match it (e.g. a LAS file renamed to .csv is rejected). The file must not be empty or over `MaxFileSizeMb`. | | |
| **Structure** | Header row with unique names; same column count on every row; data values are numbers. Delimiter `,` `;` or tab. Units in the header (`ROP (m/h)`) or in a second units row. | LAS 1.2 / 2.0 (3.0 rejected). Needs ~V (first), ~W, ~C, ~A (last). VERS and WRAP are required. ≥ 2 curves, no duplicates. One value per curve per row. Values are numbers. Missing STRT/STOP/STEP/NULL is a warning. | Well-formed XML. `<logs>` root in namespace `http://www.witsml.org/schemas/1series` (1.4.1 / 1.3.1; 2.x rejected). One `<log>`. Required: `nameWell`, `nameWellbore`, `name`, `indexType`, `indexCurve`, `logCurveInfo`, `logData/mnemonicList`, `data`. The index curve is the first mnemonic. Every mnemonic has a `logCurveInfo`. `unitList` matches. Each row has one value per mnemonic. |
| **LogType** | From the index column name: Time/DateTime/Timestamp… → time; Depth/DEPT/MD/TVD → depth. | From the first curve: DEPT/MD/TVD (or unit m/ft) → depth; TIME/ETIM (or unit s/ms) → time. | From `<indexType>`: `date time` / `elapsed time` → time; `measured depth` / `true vertical depth` / `vertical depth` / `length` → depth. |
| | Index values must be valid (date/time, or elapsed seconds; or depth numbers). Time must increase. Depth must keep one direction. | | |

## Header and data

Well, wellbore and log names come from the file header (WITSML has all three; LAS has the well name; CSV has none).
Anything missing defaults to the file name (the wellbore defaults to the well name), and the upload response
includes a warning saying so. The header is inserted into the Product Store when the job starts:

| Call | Data |
|---|---|
| `POST api/wells` | name, uid |
| `POST api/wells/{wellId}/wellbores` | name, uid |
| `POST api/wellbores/{wellboreId}/channelSets` | name, uid, indexType, indexMnemonic, indexUnit, startIndex, endIndex, sourceFormat, sourceFileName |
| `POST api/channelSets/{channelSetId}/channels` | mnemonic, unit, description (once per data curve) |

Rows go to `POST api/data/points` as `{ channelSetId, time, depth, values }`, one call per row.

**Speed / frequency**

- **Time logs** replay the real gap between rows divided by the speed. For example, rows 5 s apart at 10x are sent every 0.5 s. The wait is capped by `MaxRowDelayMs`.
- **Depth logs** have no clock, so one row is sent every `DepthRowIntervalMs` (default 1000 ms) divided by the speed.

The speed is chosen per run, so a stopped or completed job can be started again at a different speed. When it is,
the existing Product Store ids are reused.

## Job states

```
Received  -> Running | Stopped
Running   -> Stopping | Completed | Failed
Stopping  -> Stopped | Failed
Stopped / Completed / Failed -> Running   (start again / retry)
```

Stop: when Running → `Stopped` (200, or 202 while still stopping). When Received → `Stopped`. When Stopped → 200 (no change).
When Completed or Failed → 409.

## Settings (`appsettings.json`)

| Key | Default | Meaning |
|---|---|---|
| `JobStorage:StoragePath` | `App_Data/jobs` | Where uploaded files are saved (relative to the project, or an absolute path) |
| `JobStorage:MaxFileSizeMb` | 100 | Upload limit |
| `Simulation:AllowedSpeeds` | [1, 2, 5, 10] | Speeds the user can choose |
| `Simulation:DepthRowIntervalMs` | 1000 | Depth-log pace at 1x |
| `Simulation:MaxRowDelayMs` | 60000 | Longest wait between two time rows |
| `Simulation:UseSimulatedStores` | false (true in Development) | Log store calls instead of sending them |
