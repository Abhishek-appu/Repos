using System.Net.Http.Json;

namespace Simulator.Api.Services.Stores;

/// <summary>HTTP client for the product store. BaseAddress, timeout and API key are set at registration.</summary>
public sealed class ProductStoreClient(HttpClient http) : IProductStoreClient
{
    public Task<string> CreateWellAsync(string wellName, CancellationToken ct) =>
        PostForIdAsync("api/wells", new { name = wellName }, ct);

    public Task<string> CreateWellboreAsync(string wellId, string wellboreName, CancellationToken ct) =>
        PostForIdAsync($"api/wells/{Uri.EscapeDataString(wellId)}/wellbores", new { name = wellboreName }, ct);

    public Task<string> CreateChannelSetAsync(string wellboreId, string name, CancellationToken ct) =>
        PostForIdAsync($"api/wellbores/{Uri.EscapeDataString(wellboreId)}/channelSets", new { name }, ct);

    public Task<string> CreateChannelAsync(string channelSetId, string mnemonic, string unit, CancellationToken ct) =>
        PostForIdAsync($"api/channelSets/{Uri.EscapeDataString(channelSetId)}/channels", new { mnemonic, unit }, ct);

    private async Task<string> PostForIdAsync(string path, object body, CancellationToken ct)
    {
        using var response = await http.PostAsJsonAsync(path, body, ct);
        response.EnsureSuccessStatusCode();

        var result = await response.Content.ReadFromJsonAsync<IdResponse>(ct);
        return string.IsNullOrWhiteSpace(result?.Id)
            ? throw new InvalidOperationException($"Product store returned no id for '{path}'.")
            : result.Id;
    }

    private sealed record IdResponse(string Id);
}
