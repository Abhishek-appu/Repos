using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Contracts;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;

namespace Simulator.Api.Services.Jobs;

public interface IJobService
{
    /// <summary>Stores the file and registers a new job in <see cref="JobStatus.Received"/>.</summary>
    Task<SimulationJob> RegisterAsync(ReceiveJobRequest request, ParsedLog log, CancellationToken ct);

    SimulationJob Get(Guid id);
    IReadOnlyCollection<SimulationJob> GetAll();

    /// <summary>Moves the job to Running and starts the background execution.</summary>
    SimulationJob Start(Guid id);

    /// <summary>Stops a job. See remarks in the implementation for each status.</summary>
    Task<StopJobResult> StopAsync(Guid id, CancellationToken ct);
}

/// <param name="Job">The job after the stop request.</param>
/// <param name="Completed">False when the job is still Stopping after the wait timeout.</param>
public sealed record StopJobResult(SimulationJob Job, bool Completed);

public sealed class JobService(
    IJobRepository repository,
    IJobFileStorage storage,
    IJobStateMachine stateMachine,
    IJobRunner runner,
    IOptions<SimulationOptions> options,
    TimeProvider time,
    ILogger<JobService> logger) : IJobService
{
    public async Task<SimulationJob> RegisterAsync(ReceiveJobRequest request, ParsedLog log, CancellationToken ct)
    {
        ArgumentNullException.ThrowIfNull(request.File);

        var jobId = Guid.NewGuid();
        var fileName = Path.GetFileName(request.File.FileName);
        var extension = Path.GetExtension(fileName);

        string storedPath;
        await using (var content = request.File.OpenReadStream())
        {
            storedPath = await storage.SaveAsync(jobId, extension, content, ct);
        }

        var now = time.GetUtcNow();
        var job = new SimulationJob
        {
            Id = jobId,
            FileName = fileName,
            StoredFilePath = storedPath,
            LogType = log.LogType,
            WellName = request.WellName!.Trim(),
            WellboreName = request.WellboreName!.Trim(),
            LogName = request.LogName!.Trim(),
            Speed = request.Speed,
            LoopCount = request.LoopCount,
            TotalRows = log.Points.Count,
            ChannelCount = log.Channels.Count,
            ReceivedAt = now,
        };
        job.AddHistory(new JobStatusChange(null, JobStatus.Received, now, "Job received"));

        try
        {
            repository.Add(job);
        }
        catch
        {
            storage.Delete(storedPath);
            throw;
        }

        logger.LogInformation(
            "Job {JobId} received: {FileName} ({LogType}, {Rows} rows, {Channels} channels) for {Well}/{Wellbore}/{Log}",
            job.Id, job.FileName, job.LogType, job.TotalRows, job.ChannelCount, job.WellName, job.WellboreName, job.LogName);

        return job;
    }

    public SimulationJob Get(Guid id) => repository.Get(id) ?? throw new JobNotFoundException(id);

    public IReadOnlyCollection<SimulationJob> GetAll() => repository.GetAll();

    public SimulationJob Start(Guid id)
    {
        var job = Get(id);

        lock (job.SyncRoot)
        {
            if (job.Status is JobStatus.Running or JobStatus.Stopping)
                throw new InvalidJobStateException(job.Id, job.Status, $"Job is already {job.Status.ToString().ToLowerInvariant()}.");

            var reason = job.Status switch
            {
                JobStatus.Received => "Start requested",
                JobStatus.Failed => "Retry requested",
                _ => "Restart requested"
            };
            stateMachine.Transition(job, JobStatus.Running, reason);

            // Registered while holding the lock so a stop request can't slip in between
            // the status change and the execution being cancellable.
            try
            {
                runner.Run(job);
            }
            catch (Exception ex)
            {
                stateMachine.TryTransition(job, JobStatus.Failed, $"Could not start execution: {ex.Message}");
                throw;
            }
        }

        return job;
    }

    /// <remarks>
    /// Received  -> Stopped immediately (it never started).
    /// Running   -> Stopping, execution is cancelled, then we wait for it to become Stopped.
    /// Stopping  -> wait for the in-progress stop.
    /// Stopped   -> returned as-is (stop is idempotent).
    /// Completed / Failed -> 409 Conflict; there is nothing left to stop.
    /// </remarks>
    public async Task<StopJobResult> StopAsync(Guid id, CancellationToken ct)
    {
        var job = Get(id);
        var cancelRunningExecution = false;

        lock (job.SyncRoot)
        {
            switch (job.Status)
            {
                case JobStatus.Received:
                    stateMachine.Transition(job, JobStatus.Stopped, "Stopped before it was started");
                    return new StopJobResult(job, true);

                case JobStatus.Stopped:
                    return new StopJobResult(job, true);

                case JobStatus.Completed:
                    throw new InvalidJobStateException(job.Id, job.Status,
                        "Job has already completed, so there is nothing to stop.");

                case JobStatus.Failed:
                    throw new InvalidJobStateException(job.Id, job.Status,
                        "Job has already failed, so there is nothing to stop.");

                case JobStatus.Running:
                    stateMachine.Transition(job, JobStatus.Stopping, "Stop requested");
                    cancelRunningExecution = true;
                    break;

                case JobStatus.Stopping:
                    break;
            }
        }

        // Cancel outside the lock: cancellation callbacks may run inline on this thread.
        if (cancelRunningExecution && !runner.Cancel(job.Id))
        {
            // The execution ended between the status change and the cancel call.
            lock (job.SyncRoot)
            {
                stateMachine.TryTransition(job, JobStatus.Stopped, "Stop requested");
            }
            return new StopJobResult(job, true);
        }

        var timeout = TimeSpan.FromSeconds(options.Value.StopWaitTimeoutSeconds);
        var finished = await runner.WaitForExitAsync(job.Id, timeout, ct);
        if (!finished)
            logger.LogWarning("Job {JobId} is still stopping after {Timeout}", job.Id, timeout);

        return new StopJobResult(job, finished && job.Status != JobStatus.Stopping);
    }
}
