using System.Text;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// Works out the format from the extension and, separately, from the first bytes of the content,
/// so that a renamed file (e.g. LAS saved as .csv) is caught.
/// </summary>
public static class FileFormatDetector
{
    public const string SupportedTypesText = "CSV (.csv), LAS (.las) or WITSML (.xml, .witsml)";

    public static FileFormat? FromExtension(string? extension) => extension?.ToLowerInvariant() switch
    {
        ".csv" => FileFormat.Csv,
        ".las" => FileFormat.Las,
        ".xml" or ".witsml" => FileFormat.Witsml,
        _ => null
    };

    /// <summary>Returns null when the content does not look like any supported format (e.g. binary).</summary>
    public static FileFormat? FromContent(ReadOnlySpan<byte> head)
    {
        if (head.IsEmpty || head.IndexOf((byte)0) >= 0) return null; // empty or binary

        var text = Encoding.UTF8.GetString(head).TrimStart('\uFEFF', ' ', '\t', '\r', '\n');
        if (text.Length == 0) return null;
        if (text[0] == '<') return FileFormat.Witsml;

        foreach (var rawLine in text.Split('\n'))
        {
            var line = rawLine.Trim();
            if (line.Length == 0 || line.StartsWith('#')) continue;
            if (line.StartsWith('~')) return FileFormat.Las;
            return line.IndexOfAny([',', ';', '\t']) >= 0 ? FileFormat.Csv : null;
        }
        return null;
    }

    public static string DisplayName(FileFormat format) => format switch
    {
        FileFormat.Csv => "CSV",
        FileFormat.Las => "LAS",
        FileFormat.Witsml => "WITSML",
        _ => format.ToString()
    };
}
