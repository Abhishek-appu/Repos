namespace Simulator.Api.Models;

/// <summary>
/// A registered simulation job. Status changes must go through
/// <see cref="Services.Jobs.IJobStateMachine"/> so that they are validated and recorded.
/// </summary>
public sealed class SimulationJob
{
    private readonly List<JobStatusChange> _history = [];
    private int _rowsSent;
    private int _currentLoop;

    /// <summary>Lock used to make state checks and transitions atomic.</summary>
    internal object SyncRoot { get; } = new();

    // ----- Registration data (fixed once the job is received) -----
    public required Guid Id { get; init; }
    public required string FileName { get; init; }
    public required string StoredFilePath { get; init; }
    public required LogType LogType { get; init; }
    public required string WellName { get; init; }
    public required string WellboreName { get; init; }
    public required string LogName { get; init; }
    public required SimulationSpeed Speed { get; init; }
    public required int LoopCount { get; init; }
    public required int TotalRows { get; init; }
    public required int ChannelCount { get; init; }
    public required DateTimeOffset ReceivedAt { get; init; }

    // ----- Runtime state -----
    public JobStatus Status { get; internal set; } = JobStatus.Received;
    public DateTimeOffset? StartedAt { get; internal set; }
    public DateTimeOffset? EndedAt { get; internal set; }
    public int RunCount { get; internal set; }
    public string? ErrorMessage { get; internal set; }

    // Ids returned by the product store (reused if the job is restarted).
    public string? WellId { get; internal set; }
    public string? WellboreId { get; internal set; }
    public string? ChannelSetId { get; internal set; }

    public int RowsSent => Volatile.Read(ref _rowsSent);
    public int CurrentLoop => Volatile.Read(ref _currentLoop);

    public IReadOnlyList<JobStatusChange> History
    {
        get { lock (SyncRoot) return _history.ToArray(); }
    }

    internal void IncrementRowsSent() => Interlocked.Increment(ref _rowsSent);
    internal void SetCurrentLoop(int loop) => Volatile.Write(ref _currentLoop, loop);

    internal void ResetProgress()
    {
        Volatile.Write(ref _rowsSent, 0);
        Volatile.Write(ref _currentLoop, 0);
    }

    internal void AddHistory(JobStatusChange change) => _history.Add(change);
}

/// <summary>One entry in a job's status history.</summary>
public sealed record JobStatusChange(JobStatus? From, JobStatus To, DateTimeOffset At, string? Reason);
