using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;
using Simulator.Api.Services.Stores;

namespace Simulator.Api.Services.Jobs;

public interface IJobExecutor
{
    /// <summary>
    /// Runs one execution of the job: creates the well structure in the product store, then
    /// replays every row to the data store for each loop. Honors <paramref name="ct"/> for stop.
    /// </summary>
    Task ExecuteAsync(SimulationJob job, CancellationToken ct);
}

public sealed class JobExecutor(
    ILogFileParserResolver parserResolver,
    IJobFileStorage storage,
    IProductStoreClient productStore,
    IDataStoreClient dataStore,
    IOptions<SimulationOptions> options,
    TimeProvider time,
    ILogger<JobExecutor> logger) : IJobExecutor
{
    private readonly SimulationOptions _options = options.Value;

    public async Task ExecuteAsync(SimulationJob job, CancellationToken ct)
    {
        var log = await LoadLogAsync(job, ct);
        await EnsureProductStructureAsync(job, log, ct);

        for (var loop = 1; loop <= job.LoopCount; loop++)
        {
            job.SetCurrentLoop(loop);
            logger.LogInformation("Job {JobId}: loop {Loop}/{LoopCount} started", job.Id, loop, job.LoopCount);

            DataPoint? previous = null;
            foreach (var point in log.Points)
            {
                ct.ThrowIfCancellationRequested();

                var delay = CalculateDelay(job, point, previous);
                if (delay > TimeSpan.Zero) await Task.Delay(delay, time, ct);

                await dataStore.SendPointAsync(job.ChannelSetId!, point, ct);
                job.IncrementRowsSent();
                previous = point;
            }
        }

        logger.LogInformation("Job {JobId}: sent {Rows} rows", job.Id, job.RowsSent);
    }

    private async Task<ParsedLog> LoadLogAsync(SimulationJob job, CancellationToken ct)
    {
        var extension = Path.GetExtension(job.StoredFilePath);
        var parser = parserResolver.Resolve(extension)
            ?? throw new InvalidOperationException($"No parser registered for '{extension}'.");

        await using var stream = storage.OpenRead(job.StoredFilePath);
        return await parser.ParseAsync(stream, ct);
    }

    /// <summary>Creates well, wellbore, channel set and channels. Skipped when the job is re-run.</summary>
    private async Task EnsureProductStructureAsync(SimulationJob job, ParsedLog log, CancellationToken ct)
    {
        if (job.ChannelSetId is not null) return;

        job.WellId ??= await productStore.CreateWellAsync(job.WellName, ct);
        job.WellboreId ??= await productStore.CreateWellboreAsync(job.WellId, job.WellboreName, ct);

        var channelSetId = await productStore.CreateChannelSetAsync(job.WellboreId, job.LogName, ct);
        foreach (var channel in log.Channels)
            await productStore.CreateChannelAsync(channelSetId, channel.Mnemonic, channel.Unit, ct);

        // Set last so a failure half-way through recreates the channel set on retry.
        job.ChannelSetId = channelSetId;
    }

    /// <summary>
    /// Time logs: replay the real gap between rows, divided by the speed (capped by MaxRowDelayMs).
    /// Depth logs: fixed interval per row, divided by the speed.
    /// </summary>
    private TimeSpan CalculateDelay(SimulationJob job, DataPoint current, DataPoint? previous)
    {
        if (previous is null) return TimeSpan.Zero;

        var speed = (int)job.Speed;
        double ms = job.LogType switch
        {
            LogType.Time when current.Time.HasValue && previous.Time.HasValue =>
                (current.Time.Value - previous.Time.Value).TotalMilliseconds / speed,
            LogType.Depth => (double)_options.DepthRowIntervalMs / speed,
            _ => 0
        };

        return TimeSpan.FromMilliseconds(Math.Clamp(ms, 0, _options.MaxRowDelayMs));
    }
}
