using Simulator.Api.Models;

namespace Simulator.Api.Contracts;

/// <summary>multipart/form-data body for POST /api/jobs (upload) and POST /api/jobs/validate. Only the file.</summary>
public sealed class UploadFileRequest
{
    /// <summary>The log file: .csv, .las, .xml or .witsml.</summary>
    public IFormFile? File { get; set; }
}

/// <summary>JSON body for POST /api/jobs/{id}/start.</summary>
public sealed class StartJobRequest
{
    /// <summary>Speed multiplier chosen by the user: 1, 2, 5 or 10 (1x, 2x, 5x, 10x).</summary>
    public int? Speed { get; set; }

    /// <summary>Optional. How many times to replay the file (default 1).</summary>
    public int? LoopCount { get; set; }
}

public sealed record UploadJobResponse(JobResponse Job, FileValidationReport Validation);

public sealed record SimulationOptionsResponse(IReadOnlyList<int> Speeds, int MaxLoopCount, int MaxFileSizeMb, IReadOnlyList<string> FileTypes);

public sealed record JobResponse(
    Guid Id,
    JobStatus Status,
    string FileName,
    FileFormat Format,
    string? FormatVersion,
    LogType LogType,
    string IndexMnemonic,
    string IndexUnit,
    string? StartIndex,
    string? EndIndex,
    string WellName,
    string WellboreName,
    string LogName,
    int TotalRows,
    int ChannelCount,
    int? Speed,
    int LoopCount,
    int CurrentLoop,
    int RowsSent,
    double ProgressPercent,
    int RunCount,
    DateTimeOffset ReceivedAt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? EndedAt,
    string? ErrorMessage,
    string? WellId,
    string? WellboreId,
    string? ChannelSetId,
    IReadOnlyList<JobStatusChange> History)
{
    public static JobResponse From(SimulationJob job)
    {
        lock (job.SyncRoot)
        {
            var totalToSend = (long)job.TotalRows * job.LoopCount;
            var progress = totalToSend == 0 ? 0 : Math.Round(job.RowsSent * 100.0 / totalToSend, 2);

            return new JobResponse(
                job.Id, job.Status, job.FileName, job.Format, job.FormatVersion, job.LogType,
                job.IndexMnemonic, job.IndexUnit, job.StartIndex, job.EndIndex,
                job.WellName, job.WellboreName, job.LogName, job.TotalRows, job.ChannelCount,
                job.Speed, job.LoopCount, job.CurrentLoop, job.RowsSent, progress, job.RunCount,
                job.ReceivedAt, job.StartedAt, job.EndedAt, job.ErrorMessage,
                job.WellId, job.WellboreId, job.ChannelSetId, job.History);
        }
    }
}
