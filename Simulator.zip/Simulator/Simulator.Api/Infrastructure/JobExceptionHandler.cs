using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Simulator.Api.Services.Jobs;

namespace Simulator.Api.Infrastructure;

/// <summary>Turns job exceptions into ProblemDetails responses (404 / 409).</summary>
public sealed class JobExceptionHandler(IProblemDetailsService problemDetails) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(HttpContext context, Exception exception, CancellationToken ct)
    {
        ProblemDetails? details = exception switch
        {
            JobNotFoundException e => new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Job not found",
                Detail = e.Message,
                Extensions = { ["jobId"] = e.JobId }
            },
            InvalidJobStateException e => new ProblemDetails
            {
                Status = StatusCodes.Status409Conflict,
                Title = "Action not allowed in the job's current status",
                Detail = e.Message,
                Extensions = { ["jobId"] = e.JobId, ["currentStatus"] = e.CurrentStatus.ToString() }
            },
            _ => null
        };

        if (details is null) return false;

        context.Response.StatusCode = details.Status!.Value;
        return await problemDetails.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = context,
            Exception = exception,
            ProblemDetails = details
        });
    }
}
