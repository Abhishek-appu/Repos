using System.Xml;
using System.Xml.Linq;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// WITSML 1.4.1.x / 1.3.1.x log rules (WITSML 2.x is rejected):
/// <list type="bullet">
/// <item>Well-formed XML, root &lt;logs&gt; in namespace http://www.witsml.org/schemas/1series, exactly one &lt;log&gt;.</item>
/// <item>&lt;log&gt; has &lt;nameWell&gt;, &lt;nameWellbore&gt;, &lt;name&gt;, &lt;indexType&gt;, &lt;indexCurve&gt;, &lt;logCurveInfo&gt; and &lt;logData&gt;.</item>
/// <item>&lt;logData&gt; has &lt;mnemonicList&gt;, optional &lt;unitList&gt; and at least one &lt;data&gt; row.</item>
/// <item>The index curve is the first mnemonic; every mnemonic has a &lt;logCurveInfo&gt;; every row has one value per mnemonic.</item>
/// </list>
/// Log type comes from &lt;indexType&gt;: "date time" / "elapsed time" => time; "measured depth", "true vertical depth",
/// "vertical depth", "length" => depth.
/// </summary>
public sealed class WitsmlLogParser : ILogFileParser
{
    public const string Witsml1Namespace = "http://www.witsml.org/schemas/1series";

    private static readonly string[] TimeIndexTypes = ["date time", "elapsed time"];
    private static readonly string[] DepthIndexTypes = ["measured depth", "true vertical depth", "vertical depth", "length"];
    private static readonly string[] NonNumericDataTypes = ["string", "date time"];

    public FileFormat Format => FileFormat.Witsml;

    public async Task<ParseOutcome> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        var outcome = new ParseOutcome(FileFormat.Witsml);

        // ----- Well-formed XML -----
        XDocument document;
        try
        {
            var settings = new XmlReaderSettings { Async = true, DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };
            using var xmlReader = XmlReader.Create(stream, settings);
            document = await XDocument.LoadAsync(xmlReader, LoadOptions.SetLineInfo, ct);
        }
        catch (XmlException ex)
        {
            outcome.StructureError($"The XML is not well-formed (line {ex.LineNumber}, position {ex.LinePosition}): {ex.Message}");
            return outcome;
        }

        // ----- Root, namespace, version -----
        var root = document.Root!;
        var ns = root.Name.NamespaceName;

        if (ns.StartsWith("http://www.energistics.org/energyml/data/witsml", StringComparison.OrdinalIgnoreCase))
        {
            outcome.StructureError("WITSML 2.x files are not supported. Upload a WITSML 1.4.1 (or 1.3.1) log.");
            return outcome;
        }
        if (root.Name.LocalName != "logs")
        {
            outcome.StructureError($"The root element must be <logs> but is <{root.Name.LocalName}>. The file is not a WITSML log.");
            return outcome;
        }
        if (ns != Witsml1Namespace)
            outcome.StructureError(ns.Length == 0
                ? $"<logs> has no namespace. It must be xmlns=\"{Witsml1Namespace}\"."
                : $"<logs> uses namespace '{ns}' but must use '{Witsml1Namespace}'.");

        outcome.FormatVersion = (string?)root.Attribute("version");
        if (outcome.FormatVersion is null)
            outcome.Warning("<logs> has no version attribute; assuming WITSML 1.4.1.");
        else if (!outcome.FormatVersion.StartsWith("1.4.1") && !outcome.FormatVersion.StartsWith("1.3.1"))
            outcome.Warning($"WITSML version '{outcome.FormatVersion}' is not 1.4.1.x or 1.3.1.x; it was read as 1.4.1.");

        var logs = Children(root, "log").ToList();
        if (logs.Count != 1)
        {
            outcome.StructureError(logs.Count == 0
                ? "<logs> contains no <log> element."
                : $"<logs> contains {logs.Count} <log> elements. Upload one log per file.");
            return outcome;
        }
        var log = logs[0];

        // ----- Required log header elements -----
        foreach (var attribute in new[] { "uidWell", "uidWellbore", "uid" })
            if (string.IsNullOrWhiteSpace((string?)log.Attribute(attribute)))
                outcome.Warning($"<log> has no {attribute} attribute.");

        var nameWell = RequiredText(outcome, log, "nameWell");
        var nameWellbore = RequiredText(outcome, log, "nameWellbore");
        var name = RequiredText(outcome, log, "name");
        var indexType = RequiredText(outcome, log, "indexType");
        var indexCurve = RequiredText(outcome, log, "indexCurve");

        var curveInfos = Children(log, "logCurveInfo").ToList();
        if (curveInfos.Count == 0)
            outcome.StructureError("<log> has no <logCurveInfo> elements.");

        var curveByMnemonic = new Dictionary<string, XElement>(StringComparer.OrdinalIgnoreCase);
        foreach (var info in curveInfos)
        {
            var mnemonic = Text(info, "mnemonic");
            if (mnemonic is null)
                outcome.StructureError($"A <logCurveInfo> (line {LineOf(info)}) has no <mnemonic>.");
            else if (!curveByMnemonic.TryAdd(mnemonic, info))
                outcome.StructureError($"<logCurveInfo> for '{mnemonic}' appears more than once.");
        }

        var logData = Children(log, "logData").FirstOrDefault();
        if (logData is null)
        {
            outcome.StructureError("<log> has no <logData> element.");
            return outcome;
        }

        var mnemonicList = Text(logData, "mnemonicList");
        if (mnemonicList is null) outcome.StructureError("<logData> has no <mnemonicList>.");

        var dataRows = Children(logData, "data").ToList();
        if (dataRows.Count == 0) outcome.StructureError("<logData> has no <data> rows.");

        // Without these nothing below can be checked; otherwise keep going so the user sees every problem at once.
        if (mnemonicList is null || dataRows.Count == 0) return outcome;

        // ----- Mnemonics, units, curve info consistency -----
        var mnemonics = SplitList(mnemonicList, ",");
        if (mnemonics.Length < 2)
        {
            outcome.StructureError("<mnemonicList> must contain the index curve and at least one data curve.");
            return outcome;
        }
        foreach (var dup in mnemonics.GroupBy(m => m, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
            outcome.StructureError($"'{dup.Key}' appears more than once in <mnemonicList>.");
        foreach (var m in mnemonics.Where(m => !curveByMnemonic.ContainsKey(m)))
            outcome.StructureError($"'{m}' is in <mnemonicList> but has no <logCurveInfo>.");

        if (indexCurve is not null && !mnemonics[0].Equals(indexCurve, StringComparison.OrdinalIgnoreCase))
            outcome.StructureError($"<indexCurve> is '{indexCurve}' but the first entry of <mnemonicList> is '{mnemonics[0]}'. The index curve must come first.");

        var unitList = Text(logData, "unitList");
        var units = unitList is null ? [] : SplitList(unitList, ",");
        if (unitList is not null && units.Length != mnemonics.Length)
            outcome.StructureError($"<unitList> has {units.Length} entries but <mnemonicList> has {mnemonics.Length}.");

        string UnitOf(int i) =>
            i < units.Length ? units[i]
            : curveByMnemonic.TryGetValue(mnemonics[i], out var info) ? Text(info, "unit") ?? ""
            : "";

        // ----- Log type -----
        if (indexType is null) return outcome; // already reported as missing; can't check index values without it
        var logType = MapIndexType(indexType);
        outcome.LogType = logType;
        if (logType == LogType.Unknown)
        {
            outcome.LogTypeError($"<indexType> '{indexType}' is not a time or depth index. Use 'date time' / 'elapsed time' for time logs " +
                                 "or 'measured depth' / 'true vertical depth' for depth logs.");
            return outcome;
        }

        // ----- Channels (non-numeric curves are skipped with a warning) -----
        var logNull = Text(log, "nullValue");
        var channelColumns = new List<int>();
        var channels = new List<ChannelDefinition>();
        var nullByColumn = new string?[mnemonics.Length];

        for (var i = 1; i < mnemonics.Length; i++)
        {
            curveByMnemonic.TryGetValue(mnemonics[i], out var info);
            nullByColumn[i] = (info is null ? null : Text(info, "nullValue")) ?? logNull;

            var dataType = info is null ? null : Text(info, "typeLogData");
            if (dataType is not null && NonNumericDataTypes.Contains(dataType, StringComparer.OrdinalIgnoreCase))
            {
                outcome.Warning($"Curve '{mnemonics[i]}' has typeLogData '{dataType}' and will not be sent (only numeric curves are supported).");
                continue;
            }
            channelColumns.Add(i);
            channels.Add(new ChannelDefinition(mnemonics[i], UnitOf(i), info is null ? null : Text(info, "curveDescription")));
        }

        if (channels.Count == 0)
            outcome.StructureError("The log has no numeric data curves.");

        // ----- Data rows -----
        var delimiter = Text(logData, "dataDelimiter") ?? Text(log, "dataDelimiter") ?? ",";
        var indexUnit = UnitOf(0);
        var points = new List<DataPoint>(dataRows.Count);

        for (var r = 0; r < dataRows.Count && !outcome.TooManyErrors; r++)
        {
            var label = $"<data> row {r + 1} (line {LineOf(dataRows[r])})";
            var cells = dataRows[r].Value.Split(delimiter).Select(c => c.Trim()).ToArray();
            if (cells.Length != mnemonics.Length)
            {
                outcome.StructureError($"{label}: expected {mnemonics.Length} values but found {cells.Length}.");
                continue;
            }

            DateTimeOffset? time = null;
            double? depth = null;
            if (logType == LogType.Time)
            {
                if (!ValueParsing.TryParseTime(cells[0], indexUnit, out var t))
                {
                    outcome.LogTypeError($"{label}: index '{cells[0]}' is not a valid date/time.");
                    continue;
                }
                time = t;
            }
            else
            {
                if (!ValueParsing.TryParseNumber(cells[0], out var d))
                {
                    outcome.LogTypeError($"{label}: index '{cells[0]}' is not a valid depth.");
                    continue;
                }
                depth = d;
            }

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in channelColumns)
            {
                var cell = cells[c];
                if (cell.Length == 0 || cell == nullByColumn[c]) continue;

                if (ValueParsing.TryParseNumber(cell, out var v)) values[mnemonics[c]] = v;
                else outcome.StructureError($"{label}, curve '{mnemonics[c]}': '{cell}' is not a number.");
            }

            points.Add(new DataPoint(time, depth, values));
        }

        CompareWithHeader(outcome, log, logType, points, indexUnit);
        IndexChecks.Validate(outcome, logType, points);
        if (outcome.HasErrors) return outcome;

        var header = new LogHeaderInfo(
            nameWell, nameWellbore, name,
            (string?)log.Attribute("uidWell"), (string?)log.Attribute("uidWellbore"), (string?)log.Attribute("uid"));

        outcome.Log = new ParsedLog(FileFormat.Witsml, outcome.FormatVersion ?? "1.4.1", logType, mnemonics[0], indexUnit,
            header, channels, points);
        return outcome;
    }

    private static LogType MapIndexType(string indexType)
    {
        var value = indexType.Trim().ToLowerInvariant();
        if (TimeIndexTypes.Contains(value)) return LogType.Time;
        if (DepthIndexTypes.Contains(value)) return LogType.Depth;
        return LogType.Unknown;
    }

    /// <summary>Header start/end index that disagrees with the data is only a warning.</summary>
    private static void CompareWithHeader(ParseOutcome outcome, XElement log, LogType logType, List<DataPoint> points, string indexUnit)
    {
        if (points.Count == 0) return;

        if (logType == LogType.Depth)
        {
            void CheckDepth(string element, double? actual)
            {
                if (ValueParsing.TryParseNumber(Text(log, element), out var expected) && actual.HasValue
                    && Math.Abs(expected - actual.Value) > 1e-6 * Math.Max(1, Math.Abs(expected)))
                    outcome.Warning($"<{element}> is {expected} but the data {(element == "startIndex" ? "starts" : "ends")} at {actual}.");
            }
            CheckDepth("startIndex", points[0].Depth);
            CheckDepth("endIndex", points[^1].Depth);
        }
        else
        {
            void CheckTime(string element, DateTimeOffset? actual)
            {
                var text = Text(log, element);
                if (text is not null && ValueParsing.TryParseTime(text, indexUnit, out var expected) && actual.HasValue && expected != actual)
                    outcome.Warning($"<{element}> is {text} but the data {(element.StartsWith("start") ? "starts" : "ends")} at {actual:O}.");
            }
            CheckTime("startDateTimeIndex", points[0].Time);
            CheckTime("endDateTimeIndex", points[^1].Time);
        }
    }

    private static string? RequiredText(ParseOutcome outcome, XElement parent, string localName)
    {
        var value = Text(parent, localName);
        if (value is null)
            outcome.StructureError($"<{parent.Name.LocalName}> is missing the required <{localName}> element.");
        return value;
    }

    private static IEnumerable<XElement> Children(XElement parent, string localName) =>
        parent.Elements().Where(e => e.Name.LocalName == localName);

    private static string? Text(XElement parent, string localName)
    {
        var value = Children(parent, localName).FirstOrDefault()?.Value.Trim();
        return string.IsNullOrEmpty(value) ? null : value;
    }

    private static string[] SplitList(string? list, string delimiter) =>
        string.IsNullOrWhiteSpace(list) ? [] : list.Split(delimiter).Select(s => s.Trim()).ToArray();

    private static int LineOf(XElement element) => ((IXmlLineInfo)element).LineNumber;
}
