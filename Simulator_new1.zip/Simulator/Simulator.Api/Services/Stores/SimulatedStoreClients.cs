using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Services.Stores;

/// <summary>Local fake used when Simulation:UseSimulatedStores is true. Only logs.</summary>
public sealed class SimulatedProductStoreClient(ILogger<SimulatedProductStoreClient> logger) : IProductStoreClient
{
    public Task<string> CreateWellAsync(WellHeader well, CancellationToken ct) => Create("well", well);
    public Task<string> CreateWellboreAsync(string wellId, WellboreHeader wellbore, CancellationToken ct) => Create("wellbore", wellbore);
    public Task<string> CreateChannelSetAsync(string wellboreId, LogHeader log, CancellationToken ct) => Create("channel set", log);
    public Task<string> CreateChannelAsync(string channelSetId, ChannelHeader channel, CancellationToken ct) => Create("channel", channel);

    private Task<string> Create(string kind, object header)
    {
        var id = Guid.NewGuid().ToString("N");
        logger.LogInformation("[Simulated product store] Created {Kind} {Id}: {Header}", kind, id, header);
        return Task.FromResult(id);
    }
}

/// <summary>Local fake used when Simulation:UseSimulatedStores is true. Only logs.</summary>
public sealed class SimulatedDataStoreClient(ILogger<SimulatedDataStoreClient> logger) : IDataStoreClient
{
    public Task SendPointAsync(string channelSetId, DataPoint point, CancellationToken ct)
    {
        logger.LogDebug("[Simulated data store] {ChannelSetId} <- time={Time} depth={Depth} values={Count}",
            channelSetId, point.Time, point.Depth, point.Values.Count);
        return Task.CompletedTask;
    }
}
