using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Contracts;

/// <summary>multipart/form-data body for POST /api/jobs.</summary>
public sealed class ReceiveJobRequest
{
    /// <summary>Log file to simulate (.csv, .las or .xml).</summary>
    public IFormFile? File { get; set; }

    public string? WellName { get; set; }
    public string? WellboreName { get; set; }
    public string? LogName { get; set; }

    /// <summary>Original, Double, FiveX or TenX. Defaults to Original.</summary>
    public SimulationSpeed Speed { get; set; } = SimulationSpeed.Original;

    /// <summary>How many times to replay the file. Defaults to 1.</summary>
    public int LoopCount { get; set; } = 1;
}

/// <summary>multipart/form-data body for POST /api/jobs/validate.</summary>
public sealed class ValidateFileRequest
{
    public IFormFile? File { get; set; }
}

public sealed record FileValidationResponse(
    string FileName,
    LogType LogType,
    string IndexMnemonic,
    int RowCount,
    IReadOnlyList<ChannelDefinition> Channels);

public sealed record JobResponse(
    Guid Id,
    JobStatus Status,
    string FileName,
    LogType LogType,
    string WellName,
    string WellboreName,
    string LogName,
    SimulationSpeed Speed,
    int LoopCount,
    int TotalRows,
    int ChannelCount,
    int CurrentLoop,
    int RowsSent,
    double ProgressPercent,
    int RunCount,
    DateTimeOffset ReceivedAt,
    DateTimeOffset? StartedAt,
    DateTimeOffset? EndedAt,
    string? ErrorMessage,
    string? WellId,
    string? WellboreId,
    string? ChannelSetId,
    IReadOnlyList<JobStatusChange> History)
{
    public static JobResponse From(SimulationJob job)
    {
        lock (job.SyncRoot)
        {
            var totalToSend = (long)job.TotalRows * job.LoopCount;
            var progress = totalToSend == 0 ? 0 : Math.Round(job.RowsSent * 100.0 / totalToSend, 2);

            return new JobResponse(
                job.Id, job.Status, job.FileName, job.LogType,
                job.WellName, job.WellboreName, job.LogName,
                job.Speed, job.LoopCount, job.TotalRows, job.ChannelCount,
                job.CurrentLoop, job.RowsSent, progress, job.RunCount,
                job.ReceivedAt, job.StartedAt, job.EndedAt, job.ErrorMessage,
                job.WellId, job.WellboreId, job.ChannelSetId,
                job.History);
        }
    }
}
