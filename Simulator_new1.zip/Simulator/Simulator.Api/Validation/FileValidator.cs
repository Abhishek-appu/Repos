using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Contracts;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Validation;

public sealed record FileValidationOutcome(FileValidationReport Report, ParsedLog? Log);

public interface IFileValidator
{
    /// <summary>
    /// Runs the three upload checks in order:
    /// 1. Format    - is it a CSV, LAS or WITSML file (extension AND content agree)?
    /// 2. Structure - is it a properly formed file of that format?
    /// 3. LogType   - is it a time log or a depth log, with valid index values?
    /// A later check is skipped when an earlier one fails.
    /// </summary>
    Task<FileValidationOutcome> ValidateAsync(IFormFile? file, CancellationToken ct);
}

public sealed class FileValidator(
    ILogFileParserResolver parsers,
    IOptions<JobStorageOptions> storageOptions,
    ILogger<FileValidator> logger) : IFileValidator
{
    private const int MaxFileNameLength = 255;
    private const int SniffBytes = 4096;

    public async Task<FileValidationOutcome> ValidateAsync(IFormFile? file, CancellationToken ct)
    {
        var fileName = Path.GetFileName(file?.FileName ?? "");

        // ----- 1. Format -----
        var (format, formatError) = await CheckFormatAsync(file, fileName, ct);
        if (format is null)
        {
            return Result(fileName, null, null, LogType.Unknown, [],
                ValidationCheck.Fail(CheckNames.Format, formatError!),
                ValidationCheck.Skip(CheckNames.Structure, "Skipped because the format check failed."),
                ValidationCheck.Skip(CheckNames.LogType, "Skipped because the format check failed."));
        }

        var formatCheck = ValidationCheck.Pass(CheckNames.Format, $"{FileFormatDetector.DisplayName(format.Value)} file.");

        // ----- 2. Structure and 3. LogType (done in one read by the parser) -----
        ParseOutcome outcome;
        try
        {
            await using var stream = file!.OpenReadStream();
            outcome = await parsers.Get(format.Value).ParseAsync(stream, ct);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not read uploaded file {FileName}", fileName);
            return Result(fileName, format, null, LogType.Unknown, [], formatCheck,
                ValidationCheck.Fail(CheckNames.Structure, "The file could not be read."),
                ValidationCheck.Skip(CheckNames.LogType, "Skipped because the structure check failed."));
        }

        var formatLabel = FileFormatDetector.DisplayName(format.Value) + (outcome.FormatVersion is { } v ? $" {v}" : "");

        var structureCheck = outcome.StructureErrors.Count == 0
            ? ValidationCheck.Pass(CheckNames.Structure, $"Valid {formatLabel} structure.")
            : ValidationCheck.Fail(CheckNames.Structure, outcome.StructureErrors);

        ValidationCheck logTypeCheck;
        if (outcome.LogTypeErrors.Count > 0)
            logTypeCheck = ValidationCheck.Fail(CheckNames.LogType, outcome.LogTypeErrors);
        else if (outcome.LogType == LogType.Unknown)
            logTypeCheck = ValidationCheck.Skip(CheckNames.LogType, "Skipped because the structure check failed.");
        else if (outcome.Log is not null)
            logTypeCheck = ValidationCheck.Pass(CheckNames.LogType,
                $"{outcome.LogType} log indexed by '{outcome.Log.IndexMnemonic}'{(outcome.Log.IndexUnit.Length > 0 ? $" ({outcome.Log.IndexUnit})" : "")}.");
        else
            logTypeCheck = ValidationCheck.Pass(CheckNames.LogType, $"{outcome.LogType} log.");

        return new FileValidationOutcome(
            Report(fileName, format, outcome.FormatVersion, outcome.LogType, outcome.Warnings, outcome.Log,
                formatCheck, structureCheck, logTypeCheck),
            outcome.IsValid ? outcome.Log : null);
    }

    private async Task<(FileFormat? Format, string? Error)> CheckFormatAsync(IFormFile? file, string fileName, CancellationToken ct)
    {
        if (file is null) return (null, "No file was uploaded.");
        if (file.Length == 0) return (null, "The uploaded file is empty.");

        var options = storageOptions.Value;
        if (file.Length > options.MaxFileSizeBytes)
            return (null, $"The file is {file.Length / 1024d / 1024d:0.#} MB; the limit is {options.MaxFileSizeMb} MB.");

        if (string.IsNullOrWhiteSpace(fileName) || fileName.Length > MaxFileNameLength)
            return (null, $"The file name must be between 1 and {MaxFileNameLength} characters.");

        var extension = Path.GetExtension(fileName);
        var byExtension = FileFormatDetector.FromExtension(extension);
        if (byExtension is null)
            return (null, $"'{(extension.Length > 0 ? extension : fileName)}' files are not supported. Upload a {FileFormatDetector.SupportedTypesText} file.");

        var head = new byte[SniffBytes];
        int read;
        await using (var stream = file.OpenReadStream())
        {
            read = await stream.ReadAtLeastAsync(head, head.Length, throwOnEndOfStream: false, ct);
        }

        var byContent = FileFormatDetector.FromContent(head.AsSpan(0, read));
        if (byContent is null)
            return (null, $"The file has a {extension} extension but its content is not a readable {FileFormatDetector.DisplayName(byExtension.Value)} file.");
        if (byContent != byExtension)
            return (null, $"The file has a {extension} extension ({FileFormatDetector.DisplayName(byExtension.Value)}) " +
                          $"but its content looks like {FileFormatDetector.DisplayName(byContent.Value)}.");

        return (byExtension, null);
    }

    private static FileValidationOutcome Result(string fileName, FileFormat? format, string? version, LogType logType,
        IReadOnlyList<string> warnings, params ValidationCheck[] checks) =>
        new(Report(fileName, format, version, logType, warnings, null, checks), null);

    private static FileValidationReport Report(string fileName, FileFormat? format, string? version, LogType logType,
        IReadOnlyList<string> warnings, ParsedLog? log, params ValidationCheck[] checks)
    {
        var isValid = checks.All(c => c.Status == CheckStatus.Passed) && log is not null;
        var summary = log is null
            ? null
            : new LogSummary(log.IndexMnemonic, log.IndexUnit, log.StartIndex, log.EndIndex, log.Points.Count,
                log.Channels, log.Header.WellName, log.Header.WellboreName, log.Header.LogName);

        return new FileValidationReport(fileName, isValid, format, version, logType, checks, warnings, summary);
    }
}
