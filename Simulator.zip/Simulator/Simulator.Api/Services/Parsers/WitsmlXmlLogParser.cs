using System.Globalization;
using System.Xml;
using System.Xml.Linq;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// WITSML 1.4.1 style log XML: reads &lt;logData&gt; with &lt;mnemonicList&gt;, optional
/// &lt;unitList&gt; and &lt;data&gt; rows. The first mnemonic is the index.
/// </summary>
public sealed class WitsmlXmlLogParser : ILogFileParser
{
    public IReadOnlyCollection<string> SupportedExtensions { get; } = [".xml"];

    public async Task<ParsedLog> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        var settings = new XmlReaderSettings { Async = true, DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null };

        XDocument document;
        try
        {
            using var xmlReader = XmlReader.Create(stream, settings);
            document = await XDocument.LoadAsync(xmlReader, LoadOptions.None, ct);
        }
        catch (XmlException ex)
        {
            throw new LogFileFormatException($"XML is not well-formed: {ex.Message}");
        }

        var logData = document.Descendants().FirstOrDefault(e => e.Name.LocalName == "logData")
            ?? throw new LogFileFormatException("XML must contain a WITSML <logData> element.");

        var mnemonics = SplitList(Child(logData, "mnemonicList")?.Value);
        if (mnemonics.Length < 2)
            throw new LogFileFormatException("<mnemonicList> must contain an index and at least one channel.");

        var units = SplitList(Child(logData, "unitList")?.Value);
        string UnitAt(int i) => i < units.Length ? units[i] : "";

        var rows = logData.Elements().Where(e => e.Name.LocalName == "data").Select(e => e.Value).ToList();
        if (rows.Count == 0)
            throw new LogFileFormatException("<logData> contains no <data> rows.");

        var indexType = document.Descendants().FirstOrDefault(e => e.Name.LocalName == "indexType")?.Value;
        var logType = DetectLogType(indexType, rows[0].Split(',')[0].Trim());

        var channels = mnemonics.Skip(1).Select((m, i) => new ChannelDefinition(m, UnitAt(i + 1))).ToList();
        var points = new List<DataPoint>(rows.Count);

        for (var r = 0; r < rows.Count; r++)
        {
            var parts = rows[r].Split(',').Select(p => p.Trim()).ToArray();
            if (parts.Length != mnemonics.Length)
                throw new LogFileFormatException($"<data> row {r + 1}: expected {mnemonics.Length} values but found {parts.Length}.");

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            for (var c = 1; c < parts.Length; c++)
            {
                if (double.TryParse(parts[c], NumberStyles.Float, CultureInfo.InvariantCulture, out var v))
                    values[mnemonics[c]] = v;
            }

            if (logType == LogType.Time)
            {
                if (!DateTimeOffset.TryParse(parts[0], CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var t))
                    throw new LogFileFormatException($"<data> row {r + 1}: '{parts[0]}' is not a valid time.");
                points.Add(new DataPoint(t, null, values));
            }
            else
            {
                if (!double.TryParse(parts[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var d))
                    throw new LogFileFormatException($"<data> row {r + 1}: '{parts[0]}' is not a valid depth.");
                points.Add(new DataPoint(null, d, values));
            }
        }

        return new ParsedLog(logType, mnemonics[0], channels, points);
    }

    private static LogType DetectLogType(string? indexType, string firstIndexValue)
    {
        if (!string.IsNullOrWhiteSpace(indexType))
        {
            if (indexType.Contains("time", StringComparison.OrdinalIgnoreCase)) return LogType.Time;
            if (indexType.Contains("depth", StringComparison.OrdinalIgnoreCase)) return LogType.Depth;
        }

        if (double.TryParse(firstIndexValue, NumberStyles.Float, CultureInfo.InvariantCulture, out _)) return LogType.Depth;
        if (DateTimeOffset.TryParse(firstIndexValue, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out _)) return LogType.Time;

        throw new LogFileFormatException($"Cannot tell whether index value '{firstIndexValue}' is time or depth.");
    }

    private static XElement? Child(XElement parent, string localName) =>
        parent.Elements().FirstOrDefault(e => e.Name.LocalName == localName);

    private static string[] SplitList(string? list) =>
        string.IsNullOrWhiteSpace(list)
            ? []
            : list.Split(',').Select(s => s.Trim()).ToArray();
}
