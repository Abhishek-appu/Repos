namespace Simulator.Api.Models;

/// <summary>How rows in the log are indexed.</summary>
public enum LogType
{
    Unknown,
    Time,
    Depth
}

/// <summary>
/// Lifecycle of a simulation job. Allowed moves are defined in <see cref="Services.Jobs.JobStateMachine"/>.
/// </summary>
public enum JobStatus
{
    /// <summary>Job received, validated and stored; not started yet.</summary>
    Received,

    /// <summary>Job is streaming data to the stores.</summary>
    Running,

    /// <summary>Stop requested; waiting for the running execution to cancel.</summary>
    Stopping,

    /// <summary>Job was stopped by a user (or by shutdown) before finishing.</summary>
    Stopped,

    /// <summary>All rows for all loops were sent.</summary>
    Completed,

    /// <summary>Execution ended with an error.</summary>
    Failed
}

/// <summary>Playback speed multiplier.</summary>
public enum SimulationSpeed
{
    Original = 1,
    Double = 2,
    FiveX = 5,
    TenX = 10
}
