~Version
VERS. 2.0 : CWLS
WRAP. NO :
~Well
NULL. -999.25 : null
~Curve
DEPT.M : depth
GR.API : gamma
RHOB.G/C3 : density
~A
1500.0 60 2.4
1500.5 61 2.4
1501.0 62 -999.25
1501.5 63 2.4
1502.0 64 2.4
