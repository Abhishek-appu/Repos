namespace Simulator.Api.Services.Parsers;

public interface ILogFileParserResolver
{
    IReadOnlyCollection<string> SupportedExtensions { get; }
    ILogFileParser? Resolve(string extension);
}

public sealed class LogFileParserResolver(IEnumerable<ILogFileParser> parsers) : ILogFileParserResolver
{
    private readonly Dictionary<string, ILogFileParser> _byExtension = parsers
        .SelectMany(p => p.SupportedExtensions.Select(ext => (ext, p)))
        .ToDictionary(x => x.ext, x => x.p, StringComparer.OrdinalIgnoreCase);

    public IReadOnlyCollection<string> SupportedExtensions => _byExtension.Keys;

    public ILogFileParser? Resolve(string extension) =>
        string.IsNullOrEmpty(extension) ? null : _byExtension.GetValueOrDefault(extension);
}
