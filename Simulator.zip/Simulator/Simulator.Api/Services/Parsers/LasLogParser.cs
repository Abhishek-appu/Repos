using System.Globalization;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// LAS 2.0 reader. Uses ~W (NULL value), ~C (curves) and ~A (data) sections.
/// The first curve is the index: DEPT/DEPTH/MD => depth log, TIME/ETIM => time log
/// (numeric time is read as seconds, or milliseconds when the unit is "ms").
/// </summary>
public sealed class LasLogParser : ILogFileParser
{
    private static readonly string[] DepthMnemonics = ["DEPT", "DEPTH", "MD", "TVD"];
    private static readonly string[] TimeMnemonics = ["TIME", "ETIM", "DATETIME", "INDEX_TIME"];

    public IReadOnlyCollection<string> SupportedExtensions { get; } = [".las"];

    public async Task<ParsedLog> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        using var reader = new StreamReader(stream, leaveOpen: true);

        var curves = new List<ChannelDefinition>();
        var dataTokens = new List<string>();
        double? nullValue = null;
        var section = ' ';
        var lineNumber = 0;

        string? line;
        while ((line = await reader.ReadLineAsync(ct)) is not null)
        {
            lineNumber++;
            var trimmed = line.Trim();
            if (trimmed.Length == 0 || trimmed.StartsWith('#')) continue;

            if (trimmed.StartsWith('~'))
            {
                section = trimmed.Length > 1 ? char.ToUpperInvariant(trimmed[1]) : ' ';
                continue;
            }

            switch (section)
            {
                case 'W':
                    var (mnemonic, _, value) = ParseHeaderLine(trimmed);
                    if (mnemonic.Equals("NULL", StringComparison.OrdinalIgnoreCase) && TryParseNumber(value, out var nv))
                        nullValue = nv;
                    break;

                case 'C':
                    var curve = ParseHeaderLine(trimmed);
                    if (curve.Mnemonic.Length > 0) curves.Add(new ChannelDefinition(curve.Mnemonic, curve.Unit));
                    break;

                case 'A':
                    dataTokens.AddRange(trimmed.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));
                    break;
            }
        }

        if (curves.Count < 2)
            throw new LogFileFormatException("LAS file must define an index curve and at least one data curve in the ~C section.");
        if (dataTokens.Count == 0)
            throw new LogFileFormatException("LAS file has no data in the ~A section.");
        if (dataTokens.Count % curves.Count != 0)
            throw new LogFileFormatException($"LAS ~A section has {dataTokens.Count} values, which is not a multiple of the {curves.Count} curves.");

        var index = curves[0];
        var logType = DetectLogType(index);
        var channels = curves.Skip(1).ToList();
        var points = new List<DataPoint>(dataTokens.Count / curves.Count);

        for (var row = 0; row < dataTokens.Count / curves.Count; row++)
        {
            var offset = row * curves.Count;
            if (!TryParseNumber(dataTokens[offset], out var indexValue) || IsNull(indexValue, nullValue))
                throw new LogFileFormatException($"LAS data row {row + 1}: index value '{dataTokens[offset]}' is invalid.");

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            for (var c = 1; c < curves.Count; c++)
            {
                if (TryParseNumber(dataTokens[offset + c], out var v) && !IsNull(v, nullValue))
                    values[curves[c].Mnemonic] = v;
            }

            points.Add(logType == LogType.Time
                ? new DataPoint(ToTime(indexValue, index.Unit), null, values)
                : new DataPoint(null, indexValue, values));
        }

        return new ParsedLog(logType, index.Mnemonic, channels, points);
    }

    private static LogType DetectLogType(ChannelDefinition index)
    {
        if (DepthMnemonics.Contains(index.Mnemonic, StringComparer.OrdinalIgnoreCase)) return LogType.Depth;
        if (TimeMnemonics.Contains(index.Mnemonic, StringComparer.OrdinalIgnoreCase)) return LogType.Time;
        if (index.Unit is "m" or "M" or "ft" or "F" or "FT") return LogType.Depth;
        if (index.Unit is "s" or "S" or "ms" or "MS" or "sec") return LogType.Time;
        throw new LogFileFormatException($"Cannot tell whether index curve '{index.Mnemonic}' is time or depth.");
    }

    private static DateTimeOffset ToTime(double value, string unit) =>
        unit.Equals("ms", StringComparison.OrdinalIgnoreCase)
            ? DateTimeOffset.UnixEpoch.AddMilliseconds(value)
            : DateTimeOffset.UnixEpoch.AddSeconds(value);

    private static bool IsNull(double value, double? nullValue) =>
        nullValue.HasValue && Math.Abs(value - nullValue.Value) < 1e-9;

    private static bool TryParseNumber(string text, out double value) =>
        double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);

    /// <summary>Parses "MNEM.UNIT  VALUE : DESCRIPTION".</summary>
    private static (string Mnemonic, string Unit, string Value) ParseHeaderLine(string line)
    {
        var dot = line.IndexOf('.');
        if (dot < 0) return ("", "", "");

        var colon = line.LastIndexOf(':');
        if (colon < dot) colon = line.Length;

        var mnemonic = line[..dot].Trim();
        var rest = line[(dot + 1)..colon];
        var unitEnd = 0;
        while (unitEnd < rest.Length && !char.IsWhiteSpace(rest[unitEnd])) unitEnd++;

        return (mnemonic, rest[..unitEnd], rest[unitEnd..].Trim());
    }
}
