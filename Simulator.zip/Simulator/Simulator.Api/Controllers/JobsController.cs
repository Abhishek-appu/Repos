using Microsoft.AspNetCore.Mvc;
using Simulator.Api.Contracts;
using Simulator.Api.Models;
using Simulator.Api.Services.Jobs;
using Simulator.Api.Validation;

namespace Simulator.Api.Controllers;

[ApiController]
[Route("api/jobs")]
[Produces("application/json")]
public sealed class JobsController(IJobService jobService, IJobRequestValidator validator) : ControllerBase
{
    // ---------------- User story 1: receive the job ----------------

    /// <summary>Receives a job: validates the request and file, stores the file and registers the job.</summary>
    /// <response code="201">Job registered with status Received.</response>
    /// <response code="400">Request or file failed validation.</response>
    [HttpPost]
    [Consumes("multipart/form-data")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<JobResponse>> Receive([FromForm] ReceiveJobRequest request, CancellationToken ct)
    {
        var validation = await validator.ValidateAsync(request, ct);
        if (!validation.IsValid)
            return ValidationFailed(validation);

        var job = await jobService.RegisterAsync(request, validation.Log!, ct);
        return CreatedAtAction(nameof(GetById), new { id = job.Id }, JobResponse.From(job));
    }

    /// <summary>Checks a file without registering a job.</summary>
    [HttpPost("validate")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType<FileValidationResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<FileValidationResponse>> ValidateFile([FromForm] ValidateFileRequest request, CancellationToken ct)
    {
        var validation = await validator.ValidateFileAsync(request.File, ct);
        if (!validation.IsValid)
            return ValidationFailed(validation);

        var log = validation.Log!;
        return Ok(new FileValidationResponse(
            Path.GetFileName(request.File!.FileName), log.LogType, log.IndexMnemonic, log.Points.Count, log.Channels));
    }

    [HttpGet]
    [ProducesResponseType<IEnumerable<JobResponse>>(StatusCodes.Status200OK)]
    public IEnumerable<JobResponse> GetAll() => jobService.GetAll().Select(JobResponse.From);

    [HttpGet("{id:guid}")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public JobResponse GetById(Guid id) => JobResponse.From(jobService.Get(id));

    // ---------------- User story 2: start the job ----------------

    /// <summary>Starts the job. Also restarts a Stopped/Completed job or retries a Failed one.</summary>
    /// <response code="202">Execution started; poll GET /api/jobs/{id} for progress.</response>
    /// <response code="404">Job not found.</response>
    /// <response code="409">Job is already Running or Stopping.</response>
    [HttpPost("{id:guid}/start")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public ActionResult<JobResponse> Start(Guid id)
    {
        var job = jobService.Start(id);
        return AcceptedAtAction(nameof(GetById), new { id }, JobResponse.From(job));
    }

    // ---------------- User story 3: stop the job ----------------

    /// <summary>Stops the job.</summary>
    /// <response code="200">Job is Stopped (also returned if it was already stopped).</response>
    /// <response code="202">Cancellation requested but the job is still Stopping.</response>
    /// <response code="404">Job not found.</response>
    /// <response code="409">Job already Completed or Failed.</response>
    [HttpPost("{id:guid}/stop")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<JobResponse>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<JobResponse>> Stop(Guid id, CancellationToken ct)
    {
        var result = await jobService.StopAsync(id, ct);
        var response = JobResponse.From(result.Job);

        return result.Completed && response.Status == JobStatus.Stopped
            ? Ok(response)
            : AcceptedAtAction(nameof(GetById), new { id }, response);
    }

    private ActionResult ValidationFailed(JobValidationResult validation) =>
        ValidationProblem(new ValidationProblemDetails(validation.Errors.ToDictionary(e => e.Key, e => e.Value))
        {
            Title = "The job request is invalid.",
            Status = StatusCodes.Status400BadRequest
        });
}
