namespace Simulator.Api.Configuration;

public sealed class DataStoreOptions
{
    public const string SectionName = "DataStore";
    public string BaseUrl { get; set; } = "";
    public string ApiKey { get; set; } = "";
    public int TimeoutSeconds { get; set; } = 60;
}
