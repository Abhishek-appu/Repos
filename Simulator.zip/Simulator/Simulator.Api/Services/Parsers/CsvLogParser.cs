using System.Globalization;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// CSV with a header row. A column whose name contains "time" makes it a time log;
/// otherwise a column containing "depth" makes it a depth log. Units can be given in
/// the header as "ROP (m/h)" or "ROP [m/h]".
/// </summary>
public sealed class CsvLogParser : ILogFileParser
{
    public IReadOnlyCollection<string> SupportedExtensions { get; } = [".csv"];

    public async Task<ParsedLog> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        using var reader = new StreamReader(stream, leaveOpen: true);

        var headerLine = await reader.ReadLineAsync(ct);
        if (string.IsNullOrWhiteSpace(headerLine))
            throw new LogFileFormatException("CSV file is empty or has no header row.");

        var headers = SplitLine(headerLine).Select(ParseHeader).ToArray();
        if (headers.Any(h => h.Mnemonic.Length == 0))
            throw new LogFileFormatException("CSV header contains an empty column name.");

        var duplicate = headers.GroupBy(h => h.Mnemonic, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicate is not null)
            throw new LogFileFormatException($"CSV header contains duplicate column '{duplicate.Key}'.");

        var timeIndex = Array.FindIndex(headers, h => h.Mnemonic.Contains("time", StringComparison.OrdinalIgnoreCase));
        var depthIndex = Array.FindIndex(headers, h => h.Mnemonic.Contains("depth", StringComparison.OrdinalIgnoreCase));
        if (timeIndex < 0 && depthIndex < 0)
            throw new LogFileFormatException("CSV does not contain a time or depth column.");

        var logType = timeIndex >= 0 ? LogType.Time : LogType.Depth;
        var indexColumn = logType == LogType.Time ? timeIndex : depthIndex;
        var channels = headers.Where((_, i) => i != indexColumn).ToList();

        var points = new List<DataPoint>();
        var lineNumber = 1;
        string? line;
        while ((line = await reader.ReadLineAsync(ct)) is not null)
        {
            lineNumber++;
            if (string.IsNullOrWhiteSpace(line)) continue;

            var parts = SplitLine(line);
            if (parts.Length != headers.Length)
                throw new LogFileFormatException($"Line {lineNumber}: expected {headers.Length} values but found {parts.Length}.");

            DateTimeOffset? time = null;
            double? depth = null;

            if (timeIndex >= 0)
            {
                if (!DateTimeOffset.TryParse(parts[timeIndex], CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var t))
                {
                    if (logType == LogType.Time)
                        throw new LogFileFormatException($"Line {lineNumber}: '{parts[timeIndex]}' is not a valid time.");
                }
                else time = t;
            }

            if (depthIndex >= 0)
            {
                if (TryParseNumber(parts[depthIndex], out var d)) depth = d;
                else if (logType == LogType.Depth)
                    throw new LogFileFormatException($"Line {lineNumber}: '{parts[depthIndex]}' is not a valid depth.");
            }

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            for (var i = 0; i < headers.Length; i++)
            {
                if (i == indexColumn) continue;
                if (TryParseNumber(parts[i], out var value)) values[headers[i].Mnemonic] = value;
            }

            points.Add(new DataPoint(time, depth, values));
        }

        return new ParsedLog(logType, headers[indexColumn].Mnemonic, channels, points);
    }

    private static string[] SplitLine(string line) =>
        line.Split(',').Select(p => p.Trim().Trim('"').Trim()).ToArray();

    private static bool TryParseNumber(string text, out double value) =>
        double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value);

    private static ChannelDefinition ParseHeader(string header)
    {
        foreach (var (open, close) in new[] { ('(', ')'), ('[', ']') })
        {
            var start = header.IndexOf(open);
            var end = header.LastIndexOf(close);
            if (start > 0 && end > start)
                return new ChannelDefinition(header[..start].Trim(), header[(start + 1)..end].Trim());
        }
        return new ChannelDefinition(header.Trim(), "");
    }
}
