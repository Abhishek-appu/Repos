using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Contracts;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Validation;

public sealed record JobValidationResult(IReadOnlyDictionary<string, string[]> Errors, ParsedLog? Log)
{
    public bool IsValid => Errors.Count == 0;
}

public interface IJobRequestValidator
{
    /// <summary>Validates the job metadata and the uploaded file (format and content).</summary>
    Task<JobValidationResult> ValidateAsync(ReceiveJobRequest request, CancellationToken ct);

    /// <summary>Validates only the file.</summary>
    Task<JobValidationResult> ValidateFileAsync(IFormFile? file, CancellationToken ct);
}

public sealed class JobRequestValidator(
    ILogFileParserResolver parserResolver,
    IOptions<JobStorageOptions> storageOptions,
    IOptions<SimulationOptions> simulationOptions,
    ILogger<JobRequestValidator> logger) : IJobRequestValidator
{
    private const int MaxNameLength = 100;
    private const int MaxFileNameLength = 255;

    public async Task<JobValidationResult> ValidateAsync(ReceiveJobRequest request, CancellationToken ct)
    {
        var errors = new ErrorBag();

        ValidateName(errors, nameof(request.WellName), request.WellName);
        ValidateName(errors, nameof(request.WellboreName), request.WellboreName);
        ValidateName(errors, nameof(request.LogName), request.LogName);

        if (!Enum.IsDefined(request.Speed))
            errors.Add(nameof(request.Speed),
                $"Speed must be one of: {string.Join(", ", Enum.GetNames<SimulationSpeed>())}.");

        var maxLoops = simulationOptions.Value.MaxLoopCount;
        if (request.LoopCount < 1 || request.LoopCount > maxLoops)
            errors.Add(nameof(request.LoopCount), $"LoopCount must be between 1 and {maxLoops}.");

        var log = await ValidateFileCoreAsync(errors, request.File, ct);
        return errors.ToResult(log);
    }

    public async Task<JobValidationResult> ValidateFileAsync(IFormFile? file, CancellationToken ct)
    {
        var errors = new ErrorBag();
        var log = await ValidateFileCoreAsync(errors, file, ct);
        return errors.ToResult(log);
    }

    private async Task<ParsedLog?> ValidateFileCoreAsync(ErrorBag errors, IFormFile? file, CancellationToken ct)
    {
        const string key = nameof(ReceiveJobRequest.File);

        if (file is null)
        {
            errors.Add(key, "A log file is required.");
            return null;
        }
        if (file.Length == 0)
        {
            errors.Add(key, "The uploaded file is empty.");
            return null;
        }

        var maxBytes = storageOptions.Value.MaxFileSizeBytes;
        if (file.Length > maxBytes)
        {
            errors.Add(key, $"The file is larger than the {storageOptions.Value.MaxFileSizeMb} MB limit.");
            return null;
        }

        var fileName = Path.GetFileName(file.FileName ?? "");
        if (string.IsNullOrWhiteSpace(fileName) || fileName.Length > MaxFileNameLength)
        {
            errors.Add(key, $"The file name must be between 1 and {MaxFileNameLength} characters.");
            return null;
        }

        var extension = Path.GetExtension(fileName);
        var parser = parserResolver.Resolve(extension);
        if (parser is null)
        {
            errors.Add(key, $"Unsupported file type '{extension}'. Supported: {string.Join(", ", parserResolver.SupportedExtensions)}.");
            return null;
        }

        ParsedLog log;
        try
        {
            await using var stream = file.OpenReadStream();
            log = await parser.ParseAsync(stream, ct);
        }
        catch (LogFileFormatException ex)
        {
            errors.Add(key, ex.Message);
            return null;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogWarning(ex, "Could not read uploaded file {FileName}", fileName);
            errors.Add(key, "The file could not be read.");
            return null;
        }

        if (log.LogType == LogType.Unknown)
            errors.Add(key, "Could not determine whether the file is a time or depth log.");
        if (log.Channels.Count == 0)
            errors.Add(key, "The file contains no data channels.");
        if (log.Points.Count == 0)
            errors.Add(key, "The file contains no data rows.");

        if (log.LogType == LogType.Time)
        {
            for (var i = 1; i < log.Points.Count; i++)
            {
                if (log.Points[i].Time < log.Points[i - 1].Time)
                {
                    errors.Add(key, $"Time values must be in ascending order (row {i + 1} goes back in time).");
                    break;
                }
            }
        }

        return log;
    }

    private static void ValidateName(ErrorBag errors, string field, string? value)
    {
        if (string.IsNullOrWhiteSpace(value))
            errors.Add(field, $"{field} is required.");
        else if (value.Trim().Length > MaxNameLength)
            errors.Add(field, $"{field} must be at most {MaxNameLength} characters.");
        else if (value.Any(char.IsControl))
            errors.Add(field, $"{field} contains invalid characters.");
    }

    private sealed class ErrorBag
    {
        private readonly Dictionary<string, List<string>> _errors = new();

        public void Add(string field, string message)
        {
            if (!_errors.TryGetValue(field, out var list)) _errors[field] = list = [];
            list.Add(message);
        }

        public JobValidationResult ToResult(ParsedLog? log) =>
            new(_errors.ToDictionary(e => e.Key, e => e.Value.ToArray()), _errors.Count == 0 ? log : null);
    }
}
