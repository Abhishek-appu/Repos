using Simulator.Api.Models;

namespace Simulator.Api.Services.Jobs;

/// <summary>Mapped to HTTP 404.</summary>
public sealed class JobNotFoundException(Guid jobId)
    : Exception($"Job '{jobId}' was not found.")
{
    public Guid JobId { get; } = jobId;
}

/// <summary>Mapped to HTTP 409. Thrown when an action is not allowed in the job's current status.</summary>
public sealed class InvalidJobStateException(Guid jobId, JobStatus currentStatus, string message)
    : Exception(message)
{
    public Guid JobId { get; } = jobId;
    public JobStatus CurrentStatus { get; } = currentStatus;
}
