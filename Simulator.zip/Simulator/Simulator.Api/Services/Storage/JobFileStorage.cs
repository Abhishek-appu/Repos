using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;

namespace Simulator.Api.Services.Storage;

public interface IJobFileStorage
{
    /// <summary>Saves the uploaded content and returns the full path where it was stored.</summary>
    Task<string> SaveAsync(Guid jobId, string extension, Stream content, CancellationToken ct);
    Stream OpenRead(string path);
    void Delete(string path);
}

/// <summary>
/// Stores job files on local disk as "{jobId}{ext}". The user's file name is never used
/// as part of the path, so it cannot be used for path traversal.
/// </summary>
public sealed class LocalJobFileStorage : IJobFileStorage
{
    private readonly string _root;
    private readonly ILogger<LocalJobFileStorage> _logger;

    public LocalJobFileStorage(IOptions<JobStorageOptions> options, IHostEnvironment env, ILogger<LocalJobFileStorage> logger)
    {
        _root = Path.GetFullPath(Path.IsPathRooted(options.Value.StoragePath)
            ? options.Value.StoragePath
            : Path.Combine(env.ContentRootPath, options.Value.StoragePath));
        _logger = logger;
        Directory.CreateDirectory(_root);
    }

    public async Task<string> SaveAsync(Guid jobId, string extension, Stream content, CancellationToken ct)
    {
        var path = Path.Combine(_root, $"{jobId:N}{extension.ToLowerInvariant()}");
        await using var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, useAsync: true);
        await content.CopyToAsync(file, ct);
        _logger.LogDebug("Stored file for job {JobId} at {Path}", jobId, path);
        return path;
    }

    public Stream OpenRead(string path) =>
        new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 81920, useAsync: true);

    public void Delete(string path)
    {
        try
        {
            if (File.Exists(path)) File.Delete(path);
        }
        catch (IOException ex)
        {
            _logger.LogWarning(ex, "Could not delete job file {Path}", path);
        }
    }
}
