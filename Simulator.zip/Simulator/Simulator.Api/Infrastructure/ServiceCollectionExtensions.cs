using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Services.Jobs;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;
using Simulator.Api.Services.Stores;
using Simulator.Api.Validation;

namespace Simulator.Api.Infrastructure;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddSimulator(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton(TimeProvider.System);

        services.AddOptions<JobStorageOptions>().Bind(configuration.GetSection(JobStorageOptions.SectionName))
            .Validate(o => o.MaxFileSizeMb > 0 && !string.IsNullOrWhiteSpace(o.StoragePath), "Invalid JobStorage settings.")
            .ValidateOnStart();
        services.AddOptions<SimulationOptions>().Bind(configuration.GetSection(SimulationOptions.SectionName))
            .Validate(o => o.DepthRowIntervalMs >= 0 && o.MaxRowDelayMs >= 0 && o.MaxLoopCount >= 1 && o.StopWaitTimeoutSeconds >= 0,
                "Invalid Simulation settings.")
            .ValidateOnStart();

        // File parsers
        services.AddSingleton<ILogFileParser, CsvLogParser>();
        services.AddSingleton<ILogFileParser, LasLogParser>();
        services.AddSingleton<ILogFileParser, WitsmlXmlLogParser>();
        services.AddSingleton<ILogFileParserResolver, LogFileParserResolver>();

        // Receive job: validation + registration/storage
        services.AddSingleton<IJobRequestValidator, JobRequestValidator>();
        services.AddSingleton<IJobFileStorage, LocalJobFileStorage>();
        services.AddSingleton<IJobRepository, InMemoryJobRepository>();

        // Start / stop job: state machine, background runner, executor
        services.AddSingleton<IJobStateMachine, JobStateMachine>();
        services.AddSingleton<JobRunner>();
        services.AddSingleton<IJobRunner>(sp => sp.GetRequiredService<JobRunner>());
        services.AddHostedService(sp => sp.GetRequiredService<JobRunner>());
        services.AddScoped<IJobExecutor, JobExecutor>();
        services.AddSingleton<IJobService, JobService>();

        AddStores(services, configuration);
        return services;
    }

    private static void AddStores(IServiceCollection services, IConfiguration configuration)
    {
        var useSimulated = configuration.GetValue<bool>($"{SimulationOptions.SectionName}:{nameof(SimulationOptions.UseSimulatedStores)}");
        if (useSimulated)
        {
            services.AddSingleton<IProductStoreClient, SimulatedProductStoreClient>();
            services.AddSingleton<IDataStoreClient, SimulatedDataStoreClient>();
            return;
        }

        services.Configure<ProductStoreOptions>(configuration.GetSection(ProductStoreOptions.SectionName));
        services.Configure<DataStoreOptions>(configuration.GetSection(DataStoreOptions.SectionName));

        services.AddHttpClient<IProductStoreClient, ProductStoreClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<ProductStoreOptions>>().Value;
            ConfigureClient(http, "ProductStore", o.BaseUrl, o.ApiKey, o.TimeoutSeconds);
        });

        services.AddHttpClient<IDataStoreClient, DataStoreClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<DataStoreOptions>>().Value;
            ConfigureClient(http, "DataStore", o.BaseUrl, o.ApiKey, o.TimeoutSeconds);
        });
    }

    private static void ConfigureClient(HttpClient http, string name, string baseUrl, string apiKey, int timeoutSeconds)
    {
        if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var uri))
            throw new InvalidOperationException($"{name}:BaseUrl '{baseUrl}' is not a valid absolute URL.");

        // Trailing slash so relative paths like "api/wells" append to any base path.
        http.BaseAddress = uri.AbsoluteUri.EndsWith('/') ? uri : new Uri(uri.AbsoluteUri + "/");
        http.Timeout = TimeSpan.FromSeconds(timeoutSeconds);
        if (!string.IsNullOrEmpty(apiKey))
            http.DefaultRequestHeaders.Add("X-Api-Key", apiKey);
    }
}
