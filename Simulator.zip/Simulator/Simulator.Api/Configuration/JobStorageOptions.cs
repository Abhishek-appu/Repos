namespace Simulator.Api.Configuration;

public sealed class JobStorageOptions
{
    public const string SectionName = "JobStorage";

    /// <summary>Folder for uploaded job files. Relative paths are resolved from the content root.</summary>
    public string StoragePath { get; set; } = "App_Data/jobs";

    public int MaxFileSizeMb { get; set; } = 100;

    public long MaxFileSizeBytes => MaxFileSizeMb * 1024L * 1024L;
}
