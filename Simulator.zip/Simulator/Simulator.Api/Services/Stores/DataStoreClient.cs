using System.Net.Http.Json;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Services.Stores;

/// <summary>HTTP client for the data store. BaseAddress, timeout and API key are set at registration.</summary>
public sealed class DataStoreClient(HttpClient http) : IDataStoreClient
{
    public async Task SendPointAsync(string channelSetId, DataPoint point, CancellationToken ct)
    {
        var payload = new { channelSetId, time = point.Time, depth = point.Depth, values = point.Values };
        using var response = await http.PostAsJsonAsync("api/data/points", payload, ct);
        response.EnsureSuccessStatusCode();
    }
}
