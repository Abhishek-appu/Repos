using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Services.Stores;

// ----- Header information sent to the product store -----

public sealed record WellHeader(string Name, string? Uid);

public sealed record WellboreHeader(string Name, string? Uid);

/// <summary>The log (channel set) header: what it is indexed by and its range.</summary>
public sealed record LogHeader(
    string Name,
    string? Uid,
    LogType IndexType,
    string IndexMnemonic,
    string IndexUnit,
    string? StartIndex,
    string? EndIndex,
    FileFormat SourceFormat,
    string SourceFileName);

public sealed record ChannelHeader(string Mnemonic, string Unit, string? Description);

/// <summary>Product store microservice: holds the header information.</summary>
public interface IProductStoreClient
{
    Task<string> CreateWellAsync(WellHeader well, CancellationToken ct);
    Task<string> CreateWellboreAsync(string wellId, WellboreHeader wellbore, CancellationToken ct);
    Task<string> CreateChannelSetAsync(string wellboreId, LogHeader log, CancellationToken ct);
    Task<string> CreateChannelAsync(string channelSetId, ChannelHeader channel, CancellationToken ct);
}

/// <summary>Data store microservice: receives the data rows.</summary>
public interface IDataStoreClient
{
    Task SendPointAsync(string channelSetId, DataPoint point, CancellationToken ct);
}
