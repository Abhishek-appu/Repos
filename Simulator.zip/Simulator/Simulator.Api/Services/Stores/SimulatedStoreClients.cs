using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Services.Stores;

/// <summary>Local fake used when Simulation:UseSimulatedStores is true. Only logs.</summary>
public sealed class SimulatedProductStoreClient(ILogger<SimulatedProductStoreClient> logger) : IProductStoreClient
{
    public Task<string> CreateWellAsync(string wellName, CancellationToken ct) => Create("well", wellName);
    public Task<string> CreateWellboreAsync(string wellId, string wellboreName, CancellationToken ct) => Create("wellbore", wellboreName);
    public Task<string> CreateChannelSetAsync(string wellboreId, string name, CancellationToken ct) => Create("channel set", name);
    public Task<string> CreateChannelAsync(string channelSetId, string mnemonic, string unit, CancellationToken ct) => Create("channel", mnemonic);

    private Task<string> Create(string kind, string name)
    {
        var id = Guid.NewGuid().ToString("N");
        logger.LogInformation("[Simulated product store] Created {Kind} '{Name}' with id {Id}", kind, name, id);
        return Task.FromResult(id);
    }
}

/// <summary>Local fake used when Simulation:UseSimulatedStores is true. Only logs.</summary>
public sealed class SimulatedDataStoreClient(ILogger<SimulatedDataStoreClient> logger) : IDataStoreClient
{
    public Task SendPointAsync(string channelSetId, DataPoint point, CancellationToken ct)
    {
        logger.LogDebug("[Simulated data store] {ChannelSetId} <- time={Time} depth={Depth} values={Count}",
            channelSetId, point.Time, point.Depth, point.Values.Count);
        return Task.CompletedTask;
    }
}
