# Simulator API (.NET 10)

Replays well-log files (CSV, LAS, WITSML XML) to the Product Store and Data Store, as a job you can receive, start and stop.

## Run

```
cd Simulator.Api
dotnet run
```

Swagger opens at `https://localhost:7180/swagger`. In Development, `Simulation:UseSimulatedStores` is `true`, so store calls are only logged and you can test without the real services. Set it to `false` and fill in `ProductStore` / `DataStore` in `appsettings.json` to send real data.

Sample files are in `Simulator.Api/samples`, and `Simulator.Api.http` has ready-made requests.

## User stories -> code

| Story / task | Where |
|---|---|
| **Receive job** – Create Receive Job API endpoint | `POST /api/jobs` in `Controllers/JobsController.cs` |
| – Implement job request validation | `Validation/JobRequestValidator.cs` (names, speed, loop count, file size/type/content, time order) |
| – Implement job registration and storage | `JobService.RegisterAsync`, `Services/Storage/JobFileStorage.cs`, `Services/Jobs/JobRepository.cs` |
| **Start job** – Create Start Job API endpoint | `POST /api/jobs/{id}/start` |
| – Implement job execution logic | `Services/Jobs/JobExecutor.cs` (creates well structure, replays rows with speed/loop) and `JobRunner.cs` (background run) |
| – Handle job state transitions | `Services/Jobs/JobStateMachine.cs` (allowed moves + history) |
| **Stop job** – Create Stop Job API endpoint | `POST /api/jobs/{id}/stop` |
| – Implement job cancellation logic | `JobService.StopAsync` + `JobRunner.Cancel` (CancellationToken) |
| – Handle running and completed job scenarios | `JobService.StopAsync` (see table below) |

## Endpoints

| Method | Route | Result |
|---|---|---|
| POST | `/api/jobs` (multipart: `File`, `WellName`, `WellboreName`, `LogName`, `Speed`, `LoopCount`) | 201 job in `Received`, 400 validation errors |
| POST | `/api/jobs/validate` (multipart: `File`) | 200 file summary, 400 errors |
| GET | `/api/jobs`, `/api/jobs/{id}` | Job status, progress, store ids, status history |
| POST | `/api/jobs/{id}/start` | 202 `Running`, 404, 409 if already running/stopping |
| POST | `/api/jobs/{id}/stop` | see below |
| GET | `/health` | Health check |

## Job states

```
Received  -> Running | Stopped
Running   -> Stopping | Completed | Failed
Stopping  -> Stopped | Failed
Stopped / Completed / Failed -> Running   (restart / run again / retry)
```

## Stop behaviour

| Current status | Result |
|---|---|
| Running | Cancelled -> `Stopped`, 200 (202 if still `Stopping` after `StopWaitTimeoutSeconds`) |
| Stopping | Waits for the stop, 200 / 202 |
| Received | `Stopped` immediately, 200 |
| Stopped | Returned as-is, 200 (idempotent) |
| Completed / Failed | 409 Conflict – nothing to stop |

On app shutdown, running jobs are cancelled and marked `Stopped`.

## Notes

- Jobs are kept in memory (`InMemoryJobRepository`); they are lost on restart. Uploaded files are saved in `App_Data/jobs` as `{jobId}.{ext}`.
- Errors are returned as ProblemDetails (404 / 409 include `jobId`, `currentStatus`).
