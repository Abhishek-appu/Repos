using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Services.Stores;

public interface IProductStoreClient
{
    Task<string> CreateWellAsync(string wellName, CancellationToken ct);
    Task<string> CreateWellboreAsync(string wellId, string wellboreName, CancellationToken ct);
    Task<string> CreateChannelSetAsync(string wellboreId, string name, CancellationToken ct);
    Task<string> CreateChannelAsync(string channelSetId, string mnemonic, string unit, CancellationToken ct);
}

public interface IDataStoreClient
{
    Task SendPointAsync(string channelSetId, DataPoint point, CancellationToken ct);
}
