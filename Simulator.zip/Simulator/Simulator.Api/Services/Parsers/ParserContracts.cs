using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

public interface ILogFileParser
{
    /// <summary>Extensions this parser handles, lower case with leading dot (e.g. ".csv").</summary>
    IReadOnlyCollection<string> SupportedExtensions { get; }

    /// <summary>Reads the whole file. Throws <see cref="LogFileFormatException"/> when the content is invalid.</summary>
    Task<ParsedLog> ParseAsync(Stream stream, CancellationToken ct = default);
}

public sealed record ChannelDefinition(string Mnemonic, string Unit);

public sealed record DataPoint(DateTimeOffset? Time, double? Depth, IReadOnlyDictionary<string, double> Values);

public sealed record ParsedLog(
    LogType LogType,
    string IndexMnemonic,
    IReadOnlyList<ChannelDefinition> Channels,
    IReadOnlyList<DataPoint> Points);

/// <summary>The file was readable but its content is not a valid log.</summary>
public sealed class LogFileFormatException(string message) : Exception(message);
