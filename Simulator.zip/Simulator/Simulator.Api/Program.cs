using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http.Features;
using Simulator.Api.Configuration;
using Simulator.Api.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// Allow uploads up to the configured size (plus room for the other form fields).
var maxFileSizeMb = builder.Configuration.GetValue<int?>($"{JobStorageOptions.SectionName}:{nameof(JobStorageOptions.MaxFileSizeMb)}") ?? 100;
var maxRequestBytes = (maxFileSizeMb + 1) * 1024L * 1024L;
builder.WebHost.ConfigureKestrel(k => k.Limits.MaxRequestBodySize = maxRequestBytes);
builder.Services.Configure<FormOptions>(f => f.MultipartBodyLengthLimit = maxRequestBytes);

builder.Services
    .AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<JobExceptionHandler>();
builder.Services.AddHealthChecks();

builder.Services.AddSimulator(builder.Configuration);

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
